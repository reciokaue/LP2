﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int N = 0;

            var auxiliar2 = Interaction.InputBox("Quantidade de times: ", "Numero de times");
            int.TryParse(auxiliar2, out N);
    
            int saldo = 0;

            int[,] matrizGols = new int[N,3];

            for (int i = 0; i < N; i++)
            {
            
                for (int j = 0; j < matrizGols.Length; j++)
                {

                    if (j==0)
                    {
                        var auxiliar = Interaction.InputBox("Gols Feitos: ", "Entrada de Gols Feitos");
                       
                        if (!int.TryParse(auxiliar, out matrizGols[i,1]))
                        {
                            MessageBox.Show("Erro, quantidade de times maior que o permitido!");
                            j--;
                            continue;
                        }

                    }
                    else
                     if (j == 1)
                    {
                       var auxiliar = Interaction.InputBox("Gols Recebidos: ", "Entrada de Gols Recebidos");

                        if (!int.TryParse(auxiliar, out matrizGols[i,2]))
                        {
                            MessageBox.Show("Erro!");
                            j--;
                            continue;
                        }
                    }
                    
                    
                }
                saldo = matrizGols[i,1] - matrizGols[i,2];
                lstbSaida.Items.Add("Time: " + (i+1) + " Gols Feitos: " + matrizGols[i,1] + " Gols Recebidos: " + matrizGols[i,2] + " Saldo de Gols: " + saldo);


            }



        }
    }
}
